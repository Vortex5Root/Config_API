# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['config_api']

package_data = \
{'': ['*']}

install_requires = \
['pathlib>=1.0.1,<2.0.0']

setup_kwargs = {
    'name': 'config-api',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Config API Documentation\n\n## Introduction\n\nThe Config API is a Python module that allows users to manage configuration files in a structured way. It provides a simple interface to create, read, update, and delete configuration files in a specified directory.\n\n## Installation\n\nTo use the Config API, simply import the `config` class from the module.\n\n```python\nfrom config_api import config\n```\n\n## Getting Started\n\nThe `config` class provides several methods to manage configuration files. Here are some examples of how to use them:\n\n### List all configurations\n\n```python\ncfg = config()\nall_configs = cfg.configs\nprint(all_configs)\n```\n\nThis will return a list of all the configurations in the `./configs/` directory.\n\n### Add a new configuration file\n\n```python\ndata = {"key": "value"}\nmsg = cfg.add_config(data, "new_config", "path/to/dir")\nprint(msg)\n```\n\nThis will create a new configuration file named `new_config.json` in the `./configs/path/to/dir/` directory with the contents of the `data` dictionary.\n\n### Remove a configuration file\n\n```python\nmsg = cfg.remove_config("config_to_remove", "path/to/dir")\nprint(msg)\n```\n\nThis will remove the `config_to_remove.json` file from the `./configs/path/to/dir/` directory.\n\n### Get the contents of a configuration file\n\n```python\nconfig_data = cfg.get_config("config_to_get", "path/to/dir")\nprint(config_data)\n```\n\nThis will return the contents of the `config_to_get.json` file in the `./configs/path/to/dir/` directory.\n\n## Conclusion\n\nThe Config API provides a simple interface to manage configuration files in a structured way. It is easy to use and can be integrated into any Python project.\n',
    'author': 'VortexRoot',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
